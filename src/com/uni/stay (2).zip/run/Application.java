package com.uni.stay.run;

import java.sql.Connection;

import com.uni.stay.view.StayMenu;


public class Application {

	public static void main(String[] args) {
		
//		new StayMenu().areaMenu();
		
//		Connection conn = JDBCTemplate.getConnection();
	
		new StayMenu().dayChoice();
		
	}

}
