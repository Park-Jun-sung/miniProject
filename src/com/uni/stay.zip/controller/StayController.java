package com.uni.stay.controller;

public class StayController {

	public void selectByNameList() {
		
	}

}
