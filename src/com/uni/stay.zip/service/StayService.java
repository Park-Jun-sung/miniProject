package com.uni.stay.service;


import java.sql.Connection;
import java.util.ArrayList;

import com.uni.common.JDBCTemplate;
import com.uni.stay.model.dao.StayDao;
import com.uni.stay.model.dto.Stay;

public class StayService {
	
	private StayDao stayDao = new StayDao();
	
	public ArrayList<Stay> selectByNameList() {
		Connection con = JDBCTemplate.getConnection();
		
		
		return list;
	}
}
