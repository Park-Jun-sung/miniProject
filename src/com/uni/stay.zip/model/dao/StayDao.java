package com.uni.stay.model.dao;

public class StayDao {

}
